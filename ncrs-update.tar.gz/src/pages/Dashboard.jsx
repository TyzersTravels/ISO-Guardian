import { useAuth } from '../contexts/AuthContext'
import Layout from '../components/Layout'

const Dashboard = () => {
  const { userProfile } = useAuth()

  if (!userProfile) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-white">Loading profile...</div>
      </div>
    )
  }

  return (
    <Layout>
      <div className="space-y-6">
          {/* Welcome Card */}
          <div className="glass glass-border rounded-3xl p-6">
            <h2 className="text-2xl font-bold text-white mb-2">
              Welcome back, {userProfile.full_name}! 👋
            </h2>
            <p className="text-cyan-200">
              You're logged in as <span className="font-semibold">{userProfile.role}</span>
            </p>
          </div>

          {/* User Info */}
          <div className="glass glass-border rounded-3xl p-6">
            <h3 className="text-xl font-bold text-white mb-4">Your Profile</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-white/60">Email</p>
                <p className="text-white font-semibold">{userProfile.email}</p>
              </div>
              <div>
                <p className="text-sm text-white/60">Role</p>
                <p className="text-white font-semibold capitalize">{userProfile.role.replace('_', ' ')}</p>
              </div>
              <div>
                <p className="text-sm text-white/60">Company</p>
                <p className="text-white font-semibold">{userProfile.company?.name}</p>
              </div>
              <div>
                <p className="text-sm text-white/60">Subscription Tier</p>
                <p className="text-white font-semibold capitalize">{userProfile.company?.tier}</p>
              </div>
            </div>
          </div>

          {/* Standards Access */}
          <div className="glass glass-border rounded-3xl p-6">
            <h3 className="text-xl font-bold text-white mb-4">Your Standards Access</h3>
            <div className="flex gap-3 flex-wrap">
              {userProfile.standards_access.map(standard => (
                <div key={standard} className="px-4 py-2 bg-cyan-500/20 border border-cyan-500/30 rounded-xl text-cyan-300 font-semibold">
                  {standard.replace('_', ' ')}
                </div>
              ))}
            </div>
          </div>

          {/* Success Message */}
          <div className="glass glass-border rounded-3xl p-6 bg-green-500/10">
            <h3 className="text-xl font-bold text-white mb-2">🎉 Authentication Working!</h3>
            <p className="text-white/80">
              You're successfully connected to Supabase! Your data is being fetched from the database with Row Level Security enforcing multi-tenant isolation.
            </p>
            <p className="text-white/60 text-sm mt-2">
              Company ID: {userProfile.company_id}
            </p>
          </div>
        </div>
      </div>
    </Layout>
  )
}

export default Dashboard
