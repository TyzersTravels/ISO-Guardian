import { useState, useEffect } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { supabase } from '../lib/supabase'

const Documents = () => {
  const { userProfile } = useAuth()
  const [documents, setDocuments] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  
  // Filters
  const [searchTerm, setSearchTerm] = useState('')
  const [standardFilter, setStandardFilter] = useState('all')
  const [clauseFilter, setClauseFilter] = useState('all')
  const [typeFilter, setTypeFilter] = useState('all')

  useEffect(() => {
    fetchDocuments()
  }, [])

  const fetchDocuments = async () => {
    try {
      setLoading(true)
      
      let query = supabase
        .from('documents')
        .select('*')

      const { data, error: fetchError } = await query

      if (fetchError) throw fetchError

      // Filter by user's standards access
      const filteredDocs = data.filter(doc => 
        userProfile.standards_access.includes(doc.standard)
      )

      setDocuments(filteredDocs)
      setError(null)
    } catch (err) {
      console.error('Error fetching documents:', err)
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  // Apply filters
  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStandard = standardFilter === 'all' || doc.standard === standardFilter
    const matchesClause = clauseFilter === 'all' || doc.clause === parseInt(clauseFilter)
    const matchesType = typeFilter === 'all' || doc.type === typeFilter

    return matchesSearch && matchesStandard && matchesClause && matchesType
  })

  // Group documents by standard and clause
  const groupedDocs = filteredDocuments.reduce((acc, doc) => {
    if (!acc[doc.standard]) acc[doc.standard] = {}
    if (!acc[doc.standard][doc.clause]) acc[doc.standard][doc.clause] = []
    acc[doc.standard][doc.clause].push(doc)
    return acc
  }, {})

  const clearFilters = () => {
    setSearchTerm('')
    setStandardFilter('all')
    setClauseFilter('all')
    setTypeFilter('all')
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-400 mx-auto mb-4"></div>
          Loading documents...
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="glass glass-border rounded-2xl p-6 max-w-md">
          <p className="text-red-300">Error: {error}</p>
          <button onClick={fetchDocuments} className="mt-4 px-4 py-2 bg-cyan-500 rounded-xl text-white">
            Retry
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Document Management</h2>
          <p className="text-cyan-200 text-sm">
            {filteredDocuments.length} of {documents.length} documents
          </p>
        </div>
        <button className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-xl flex items-center gap-2 hover:scale-105 transition-transform shadow-lg">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
          </svg>
          Upload Document
        </button>
      </div>

      {/* Search & Filters */}
      <div className="glass glass-border rounded-2xl p-4">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          {/* Search */}
          <input
            type="text"
            placeholder="Search documents..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="px-4 py-2 glass glass-border rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-cyan-400"
          />

          {/* Standard Filter */}
          <select
            value={standardFilter}
            onChange={(e) => setStandardFilter(e.target.value)}
            className="px-4 py-2 glass glass-border rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-400 bg-transparent"
          >
            <option value="all" className="bg-slate-800">All Standards</option>
            {userProfile.standards_access.map(std => (
              <option key={std} value={std} className="bg-slate-800">
                {std.replace('_', ' ')}
              </option>
            ))}
          </select>

          {/* Clause Filter */}
          <select
            value={clauseFilter}
            onChange={(e) => setClauseFilter(e.target.value)}
            className="px-4 py-2 glass glass-border rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-400 bg-transparent"
          >
            <option value="all" className="bg-slate-800">All Clauses</option>
            {[4, 5, 6, 7, 8, 9, 10].map(n => (
              <option key={n} value={n} className="bg-slate-800">Clause {n}</option>
            ))}
          </select>

          {/* Type Filter */}
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-4 py-2 glass glass-border rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-cyan-400 bg-transparent"
          >
            <option value="all" className="bg-slate-800">All Types</option>
            <option value="Policy" className="bg-slate-800">Policy</option>
            <option value="Procedure" className="bg-slate-800">Procedure</option>
            <option value="Form" className="bg-slate-800">Form</option>
            <option value="Manual" className="bg-slate-800">Manual</option>
            <option value="Record" className="bg-slate-800">Record</option>
          </select>

          {/* Clear Filters */}
          <button
            onClick={clearFilters}
            className="px-4 py-2 glass glass-border rounded-xl text-white hover:bg-white/10 transition-colors"
          >
            Clear All
          </button>
        </div>
      </div>

      {/* Documents by Standard & Clause */}
      {Object.keys(groupedDocs).length === 0 ? (
        <div className="glass glass-border rounded-2xl p-8 text-center">
          <p className="text-white/60">No documents found matching your filters.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {Object.entries(groupedDocs).map(([standard, clauses]) => (
            <div key={standard} className="glass glass-border rounded-2xl p-4">
              <h3 className="text-xl font-bold text-white mb-4">
                {standard.replace('_', ' ')}
              </h3>
              
              {Object.entries(clauses).map(([clause, docs]) => (
                <div key={clause} className="mb-4 last:mb-0">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-lg font-semibold text-cyan-300">
                      Clause {clause}: {docs[0].clause_name.split(':')[1]}
                    </h4>
                    <span className="text-sm text-white/60">
                      {docs.length} document{docs.length !== 1 ? 's' : ''}
                    </span>
                  </div>
                  
                  <div className="space-y-2">
                    {docs.map(doc => (
                      <div
                        key={doc.id}
                        className="glass glass-border rounded-xl p-4 hover:bg-white/5 transition-colors"
                      >
                        <div className="flex items-start gap-4">
                          <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center flex-shrink-0">
                            <svg className="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                          </div>
                          
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-semibold text-white">{doc.name}</span>
                              <span className="text-xs px-2 py-1 rounded-full bg-green-500/20 text-green-300">
                                {doc.status}
                              </span>
                            </div>
                            
                            <div className="flex items-center gap-3 text-sm text-white/60 mb-2">
                              <span>{doc.type}</span>
                              <span>•</span>
                              <span>Version {doc.version}</span>
                              <span>•</span>
                              <span>Updated {new Date(doc.updated_at).toLocaleDateString()}</span>
                            </div>
                            
                            {doc.next_review_date && (
                              <div className="text-xs text-white/50">
                                Next review: {new Date(doc.next_review_date).toLocaleDateString()}
                              </div>
                            )}
                          </div>
                          
                          <button className="px-4 py-2 glass glass-border text-white rounded-lg hover:bg-white/10 transition-colors text-sm">
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                            </svg>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}

      {/* Role-based notice */}
      {userProfile.role === 'quality_manager' && (
        <div className="glass glass-border rounded-2xl p-4 bg-orange-500/10">
          <p className="text-orange-200 text-sm">
            ℹ️ As a Quality Manager, you only see ISO 9001 documents. Contact an Admin for access to other standards.
          </p>
        </div>
      )}

      <style>{`
        .glass {
          background: rgba(255, 255, 255, 0.1);
          backdrop-filter: blur(20px);
          -webkit-backdrop-filter: blur(20px);
        }
        .glass-border {
          border: 1px solid rgba(255, 255, 255, 0.2);
        }
      `}</style>
    </div>
  )
}

export default Documents
